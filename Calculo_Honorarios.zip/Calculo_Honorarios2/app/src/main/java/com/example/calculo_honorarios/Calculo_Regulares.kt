package com.example.calculo_honorarios

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class Calculo_Regulares : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_calculo_regulares2)

       val btnvolver = findViewById<Button>(R.id.btnVolver)
        btnvolver.setOnClickListener(){
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)

        }
        val sueldoRegularEditText = findViewById<EditText>(R.id.SueldoRegular)
        val calcularButton = findViewById<Button>(R.id.btnCalcular)
        val resultadoTextView = findViewById<TextView>(R.id.tvTitulo)
        val btnVolver = findViewById<Button>(R.id.btnVolver)

        calcularButton.setOnClickListener {
            val sueldoRegular = sueldoRegularEditText.text.toString().toDoubleOrNull()
            if (sueldoRegular != null) {
                // Calcular salario neto restando el 20% del sueldo bruto
                val salarioNeto = sueldoRegular - (sueldoRegular * 0.20)
                resultadoTextView.text = "Salario neto: $salarioNeto"
            } else {
                resultadoTextView.text = "Por favor ingrese un sueldo válido"
            }
        }


    }
}





