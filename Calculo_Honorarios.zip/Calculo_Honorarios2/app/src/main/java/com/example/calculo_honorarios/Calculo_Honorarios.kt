package com.example.calculo_honorarios

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview

class Calculo_Honorarios : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PantallaCalculoHonorarios()
        }
    }
}

@Preview
@Composable
fun PantallaCalculoHonorarios() {
    val contexto = LocalContext.current
    val salarioBrutoState = remember { mutableStateOf(TextFieldValue()) }
    val salarioNetoState = remember { mutableStateOf<Double?>(null) }
    val errorState = remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().background(Color.Cyan),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = salarioBrutoState.value,
            onValueChange = { salarioBrutoState.value = it },
            label = { Text("Salario Bruto") },
            modifier = Modifier.fillMaxWidth()
        )

        if (errorState.value) {
            Text("Ingrese un número válido para el salario bruto", color = Color.Red)
        }

        Button(onClick = {
            val salarioBruto = salarioBrutoState.value.text.toDoubleOrNull()
            if (salarioBruto != null) {
                val salarioNeto = calcularPagoHonorarios(salarioBruto)
                salarioNetoState.value = salarioNeto
                errorState.value = false // Reinicia el estado de error si había un error previo
            } else {
                errorState.value = true
            }
        }) {
            Text("Calcular Honorarios")
        }

        salarioNetoState.value?.let { salarioNeto ->
            Text("Salario Neto: $salarioNeto")
        }



        Button(onClick = {
            val intent = Intent(contexto, MainActivity::class.java)
            contexto.startActivity(intent)
        }) {
            Text("Volver")
        }
    }
}

fun calcularPagoHonorarios(salarioBruto: Double): Double {
    val retencionPorcentaje = 0.13 // Porcentaje de retención para honorarios
    val retencion = salarioBruto * retencionPorcentaje
    val salarioNeto = salarioBruto - retencion
    return salarioNeto
}
